"""
firewall.py — the "PREVENT" step. Blocks a malicious IP using iptables.

Safety notes for the demo:
  - Requires sudo / root (Kali's default user has sudo).
  - Never runs unless --prevent is passed AND severity crosses the threshold.
  - dry_run=True (the default when not on Linux, e.g. testing on your own
    laptop before moving to the Kali VM) just prints the command instead
    of executing it, so you can safely demo the LOGIC without touching
    real firewall rules if you're not on the Kali VM yet.
"""

import platform
import subprocess


def block_ip(ip: str, dry_run: bool = False) -> str:
    cmd = ["sudo", "iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"]

    if dry_run or platform.system() != "Linux":
        return f"[DRY RUN] Would execute: {' '.join(cmd)}"

    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=5)
        return f"BLOCKED: {ip} dropped via iptables"
    except subprocess.CalledProcessError as e:
        return f"FAILED to block {ip}: {e.stderr.strip()}"
    except FileNotFoundError:
        return "FAILED: iptables not found on this system"
    except Exception as e:
        return f"FAILED to block {ip}: {e}"


def list_blocked() -> str:
    """Show current DROP rules added by VantaCore (best-effort demo helper)."""
    try:
        result = subprocess.run(
            ["sudo", "iptables", "-L", "INPUT", "-n"],
            check=True, capture_output=True, text=True, timeout=5,
        )
        return result.stdout
    except Exception as e:
        return f"Could not list rules: {e}"
