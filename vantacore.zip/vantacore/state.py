"""
state.py — the shared "nervous system" between VantaCore's CLI and its
live dashboard.

When vantacore.py finishes a scan, or the --live monitor fires an alert,
it calls into this module, which writes to dashboard_state.json.
The dashboard (dashboard/server.py) reads that same file and decides,
on every request, whether the system is currently SECURE or UNDER_ATTACK.

This is a real data pipeline, not a scripted animation: the dashboard
only turns red because an actual scan or packet capture flagged
something, and it only turns red for ATTACK_WINDOW_SECONDS after the
last real alert -- then goes back to green on its own, the same way a
SOC dashboard would.
"""

import json
import os
import time
from threading import Lock

STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dashboard_state.json")
ATTACK_WINDOW_SECONDS = 20  # how long a category stays "lit up red" after its last alert
MAX_EVENTS = 100

_lock = Lock()

DEFAULT_STATE = {
    "target": None,
    "severity": 0.0,
    "verdict": "SECURE",
    "events": [],  # [{epoch, time, message, level, threat_type}]
}


def _load() -> dict:
    if not os.path.exists(STATE_FILE):
        return dict(DEFAULT_STATE)
    try:
        with open(STATE_FILE) as f:
            data = json.load(f)
            for k, v in DEFAULT_STATE.items():
                data.setdefault(k, v)
            return data
    except Exception:
        return dict(DEFAULT_STATE)


def _save(state: dict):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def _push_event(state: dict, epoch: float, message: str, level: str, threat_type: str = None):
    state["events"].append({
        "epoch": epoch,
        "time": time.strftime("%H:%M:%S", time.localtime(epoch)),
        "message": message,
        "level": level,           # "alert" or "info"
        "threat_type": threat_type,
    })
    state["events"] = state["events"][-MAX_EVENTS:]


def reset():
    """Wipe the dashboard state -- useful before a fresh demo run."""
    with _lock:
        _save(dict(DEFAULT_STATE))


def update_from_scan(target: str, verdict: dict):
    """Called by vantacore.py after a --target scan finishes."""
    with _lock:
        state = _load()
        state["target"] = target
        state["severity"] = verdict["severity"]
        state["verdict"] = verdict["verdict"]
        now = time.time()

        threats = [] if verdict["threats"] == ["None detected"] else verdict["threats"]
        if threats:
            for t in threats:
                _push_event(state, now, f"{t} detected on {target}", "alert", threat_type=t)
        else:
            _push_event(state, now, f"Scan on {target} came back clean", "info")
        _save(state)


def update_from_live_alert(alert: dict):
    """Called by vantacore.py's --live monitor whenever scapy fires an alert."""
    with _lock:
        state = _load()
        now = time.time()
        _push_event(
            state, now,
            f"LIVE: {alert['type']} from {alert['src']} — {alert['detail']}",
            "alert", threat_type=alert["type"],
        )
        _save(state)


def get_dashboard_snapshot() -> dict:
    """Used by the Flask server -- computes CURRENT status from recent events."""
    state = _load()
    now = time.time()
    recent = [e for e in state["events"] if now - e["epoch"] < ATTACK_WINDOW_SECONDS]
    active_threats = sorted({e["threat_type"] for e in recent
                              if e["level"] == "alert" and e["threat_type"]})
    return {
        "status": "UNDER_ATTACK" if active_threats else "SECURE",
        "severity": state.get("severity", 0.0),
        "target": state.get("target"),
        "active_threats": active_threats,
        "events": list(reversed(state["events"]))[:30],
    }
