"""
detect.py — live network monitor mode (`vantacore.py --live`).

Watches traffic on an interface and flags two of the six threat
categories in real time:
  - Port Scanning     : many distinct destination ports from one source, fast
  - DoS / Flood       : packet rate from one source crosses a threshold

Requires: scapy, and root privileges (sudo) to sniff.
On Kali this is already installed; if not: sudo apt install python3-scapy
"""

import time
from collections import defaultdict

try:
    from scapy.all import sniff, IP, TCP
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

PORT_SCAN_THRESHOLD = 15     # distinct ports from one IP within WINDOW_SECONDS
DOS_PACKET_THRESHOLD = 200   # packets from one IP within WINDOW_SECONDS
WINDOW_SECONDS = 10


class LiveMonitor:
    def __init__(self, on_alert):
        self.on_alert = on_alert          # callback(alert_dict)
        self.port_hits = defaultdict(set)  # src_ip -> set(dst_ports)
        self.packet_counts = defaultdict(int)
        self.window_start = time.time()

    def _reset_if_needed(self):
        if time.time() - self.window_start > WINDOW_SECONDS:
            self.port_hits.clear()
            self.packet_counts.clear()
            self.window_start = time.time()

    def _handle_packet(self, pkt):
        if not pkt.haslayer(IP):
            return
        src = pkt[IP].src
        self.packet_counts[src] += 1

        if pkt.haslayer(TCP):
            self.port_hits[src].add(pkt[TCP].dport)

        if len(self.port_hits[src]) >= PORT_SCAN_THRESHOLD:
            self.on_alert({
                "type": "Port Scanning",
                "src": src,
                "detail": f"{len(self.port_hits[src])} distinct ports in {WINDOW_SECONDS}s",
            })
            self.port_hits[src].clear()

        if self.packet_counts[src] >= DOS_PACKET_THRESHOLD:
            self.on_alert({
                "type": "DoS / Flood",
                "src": src,
                "detail": f"{self.packet_counts[src]} packets in {WINDOW_SECONDS}s",
            })
            self.packet_counts[src] = 0

        self._reset_if_needed()

    def start(self, iface=None):
        if not SCAPY_AVAILABLE:
            raise RuntimeError(
                "scapy is not installed. Run: pip install scapy  "
                "(or: sudo apt install python3-scapy on Kali)"
            )
        sniff(iface=iface, prn=self._handle_packet, store=False)
