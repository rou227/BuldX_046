"""
dashboard/server.py — serves the live VantaCore dashboard.

Run this in ONE terminal:
    python3 dashboard/server.py
Then open http://127.0.0.1:5050 in a browser.

In ANOTHER terminal (same vantacore/ folder), run your normal scans or
--live monitor — the dashboard updates automatically because both
processes read/write the same dashboard_state.json file via state.py.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, jsonify, send_from_directory

import state
from correlate import THREAT_CATEGORIES

app = Flask(__name__, static_folder="static", static_url_path="")


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/api/status")
def api_status():
    snapshot = state.get_dashboard_snapshot()
    snapshot["categories"] = THREAT_CATEGORIES
    return jsonify(snapshot)


if __name__ == "__main__":
    print("VantaCore dashboard running at http://127.0.0.1:5050")
    app.run(host="0.0.0.0", port=5050, debug=False)
