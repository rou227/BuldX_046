# VantaCore

A single-CLI threat-intelligence aggregator + correlation engine + prevention
tool, built for Kali Linux. It pulls data from AbuseIPDB, VirusTotal, Shodan,
AlienVault OTX and NVD/NIST, scores a target 0–10 with a rule-based
correlation engine, and can automatically block high-severity IPs with
iptables. It also ships a **live browser dashboard**: a system node that
glows green when secure and turns red the instant a real scan or live
packet-monitor alert flags a threat.

Covers 6 threat categories:
1. Brute Force / Credential Stuffing
2. Port Scanning
3. Known Malicious IPs
4. Phishing Domains
5. CVE Exploit Attempts
6. DoS / Flood

---

## 1. Setup on your Kali VM (VMware)

```bash
# copy the vantacore/ folder into your Kali VM, then:
cd vantacore
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
nano .env   # paste any free-tier API keys you have (see below) -- optional
```

Free API keys (all optional — leave blank to auto-fallback to demo data):
- AbuseIPDB: https://www.abuseipdb.com/account/api
- VirusTotal: https://www.virustotal.com/gui/my-apikey
- Shodan: https://account.shodan.io/
- AlienVault OTX: https://otx.alienvault.com/api
- IPinfo: https://ipinfo.io/signup
- NVD: works without a key, just rate-limited

**If your demo room has no reliable Wi-Fi, or you don't want to sign up for
keys the night before, just use `--demo` — see below. It's not a fallback,
it's a built-in feature: real deployments would use live keys, coursework
demos use `--demo` for guaranteed, repeatable results.**

## 2. Running it

```bash
# Full lookup + report on a target IP
python3 vantacore.py --target 45.33.32.156

# Same, but guaranteed to work with zero internet / zero API keys
python3 vantacore.py --target 45.33.32.156 --demo

# Also auto-block via iptables if severity >= 7.0
sudo python3 vantacore.py --target 45.33.32.156 --demo --prevent

# See the block command without touching real firewall rules
python3 vantacore.py --target 45.33.32.156 --demo --prevent --dry-run

# Export a report for documentation
python3 vantacore.py --target 45.33.32.156 --demo --export json
python3 vantacore.py --target 45.33.32.156 --demo --export html

# Live network monitor: flags port scans and DoS floods on your own
# traffic in real time (needs sudo + scapy; run this on the Kali VM only)
sudo python3 vantacore.py --live
```

## 3. Live dashboard (green = secure, red = under attack)

The dashboard is a real Flask app, not an animation — it reads the exact
same severity/threat data your CLI just calculated, from a shared file
called `dashboard_state.json` that `vantacore.py` writes to after every
scan or live alert.

```bash
# Terminal 1 — start the dashboard
python3 dashboard/server.py
# then open http://127.0.0.1:5050 in a browser (Firefox is preinstalled on Kali)

# Terminal 2 — run scans as normal, same vantacore/ folder
python3 vantacore.py --target 45.33.32.156 --demo
```

What you'll see:
- A center "SYSTEM" node and six threat nodes (matching your 6 threat
  categories) arranged around it.
- The moment a scan reports a threat, that node + its connecting line +
  the center core turn red and glow, and the top banner flashes
  "UNDER ATTACK".
- After 20 seconds with no new alert for that category, it fades back to
  green automatically — a real SOC dashboard behaves the same way
  (alerts age out, they don't stay lit forever).
- A live severity gauge (0–10) and a scrolling event log underneath,
  both driven from the same real data.

For the live network monitor, run `sudo python3 vantacore.py --live` in
Terminal 2 instead — every real port-scan/DoS packet-rate alert from
`detect.py` will also light up the dashboard in real time.

## 4. How it works — by point (for your presentation)

**Step 1 — Input**
You give VantaCore a single IP or domain via `--target`.

**Step 2 — Parallel API calls**
VantaCore queries AbuseIPDB, VirusTotal, Shodan, IPinfo and AlienVault OTX
*at the same time* using a thread pool (`concurrent.futures`), instead of
one after another — this is what makes a 5-source lookup finish in ~1
second instead of ~5. NVD is queried afterward, using any CVE that Shodan
reported, to get a CVSS severity score for that vulnerability.

**Step 3 — Correlation engine (`correlate.py`)**
This is the part that makes VantaCore more than "5 API calls printed to a
screen." Each source contributes a weighted score:
- AbuseIPDB confidence → up to 4.0 points
- VirusTotal malicious engine ratio → up to 3.0 points
- Shodan open-port count → up to 1.5 points
- NVD CVSS score → up to 1.0 point
- OTX community pulses → up to 0.5 points

These sum into one **unified severity score out of 10**, and the same
data is pattern-matched against the 6 threat categories (e.g. 3+ open
ports → tagged as Port Scanning; a CVE with CVSS ≥ 7 → CVE Exploit
Attempt).

**Step 4 — Prevent**
If `--prevent` is passed and the severity crosses the threshold (7.0 by
default, in `config.py`), VantaCore runs `iptables -A INPUT -s <ip> -j
DROP` to block the source at the firewall. `--dry-run` shows the exact
command without executing it — useful for a safe demo.

**Step 5 — Report**
Results print as a Rich-formatted table + severity panel in the
terminal, and can be exported to JSON (for other tools to ingest) or
HTML (for a written report / documentation).

**Bonus — Live monitor (`detect.py`)**
Separately from the lookup workflow, `--live` uses `scapy` to sniff live
traffic and flags two behavioral threats *without needing any API*: a
single source hitting 15+ distinct ports in 10 seconds (port scan), or
200+ packets from one source in 10 seconds (DoS/flood).

## 5. Project structure

```
vantacore/
├── vantacore.py       # CLI entry point — argument parsing, orchestration
├── config.py          # API key loading, thresholds
├── correlate.py        # the scoring / correlation engine
├── report.py            # Rich console output + JSON/HTML export
├── firewall.py           # iptables blocking (with dry-run safety)
├── detect.py               # live scapy-based port-scan/DoS detection
├── state.py                 # shared state bridge -> feeds the dashboard
├── dashboard/
│   ├── server.py             # Flask app serving the live dashboard
│   └── static/index.html       # the radar UI (HTML/CSS/JS, no build step)
├── modules/
│   ├── abuseipdb.py
│   ├── virustotal.py
│   ├── shodan_api.py
│   ├── nvd.py
│   ├── ipinfo.py
│   ├── otx.py
│   └── demo_data.py    # deterministic simulated data for --demo mode
├── requirements.txt
└── .env.example
```

## 6. If something breaks right before your demo

- `ModuleNotFoundError` → you forgot `pip install -r requirements.txt`
  inside your venv.
- No internet in the room → add `--demo` to every command, it does not
  touch the network at all.
- `iptables: permission denied` → you forgot `sudo` before `python3`.
- Want to prove the prevention step without risking your own SSH
  session getting cut off → always use `--dry-run` in front of a live
  audience unless you've tested the exact command beforehand.
