"""
VantaCore - config.py
Loads API keys from a .env file (or environment variables).
Missing keys are NEVER fatal -- that source is skipped or simulated
so the live demo never crashes because of a missing/expired key.
"""

import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # python-dotenv not installed -> fall back to plain env vars


class Config:
    ABUSEIPDB_KEY = os.getenv("ABUSEIPDB_KEY", "")
    VIRUSTOTAL_KEY = os.getenv("VIRUSTOTAL_KEY", "")
    SHODAN_KEY = os.getenv("SHODAN_KEY", "")
    OTX_KEY = os.getenv("OTX_KEY", "")
    NVD_KEY = os.getenv("NVD_KEY", "")       # NVD works keyless too, just slower
    IPINFO_KEY = os.getenv("IPINFO_KEY", "")

    SEVERITY_PREVENT_THRESHOLD = 7.0         # >= this triggers --prevent action
    REPORTS_DIR = "reports"

    @classmethod
    def missing_keys(cls):
        keys = {
            "AbuseIPDB": cls.ABUSEIPDB_KEY,
            "VirusTotal": cls.VIRUSTOTAL_KEY,
            "Shodan": cls.SHODAN_KEY,
            "OTX": cls.OTX_KEY,
            "IPinfo": cls.IPINFO_KEY,
        }
        return [name for name, val in keys.items() if not val]
