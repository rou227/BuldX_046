#!/usr/bin/env python3
"""
VantaCore — unified CLI threat-intelligence & prevention tool.

USAGE EXAMPLES
  python3 vantacore.py --target 45.33.32.156
  python3 vantacore.py --target 45.33.32.156 --prevent
  python3 vantacore.py --target 45.33.32.156 --export json
  python3 vantacore.py --target 45.33.32.156 --export html
  python3 vantacore.py --target 45.33.32.156 --demo
  python3 vantacore.py --live                       (live port-scan/DoS monitor)
"""

import argparse
import concurrent.futures as cf
import sys

from config import Config
from modules import abuseipdb, virustotal, shodan_api, nvd, ipinfo, otx
import correlate
import report
import firewall
import state


def gather(target: str, demo: bool) -> dict:
    """Runs every feed lookup IN PARALLEL for speed (the 'API 02' step)."""
    jobs = {
        "abuseipdb": (abuseipdb.query, target),
        "virustotal": (virustotal.query, target),
        "shodan": (shodan_api.query, target),
        "ipinfo": (ipinfo.query, target),
        "otx": (otx.query, target),
    }
    results = {}
    with cf.ThreadPoolExecutor(max_workers=len(jobs)) as pool:
        futures = {pool.submit(fn, tgt, demo=demo): name for name, (fn, tgt) in jobs.items()}
        for fut in cf.as_completed(futures):
            name = futures[fut]
            try:
                results[name] = fut.result()
            except Exception as e:
                results[name] = {"source": name, "ok": False, "raw_note": str(e)}

    # NVD is looked up separately because it depends on a CVE, which we
    # only know about after Shodan reports vulns (or demo mode).
    shodan_vulns = results.get("shodan", {}).get("vulns", [])
    cve_hint = shodan_vulns[0] if shodan_vulns else ""
    results["nvd"] = nvd.query(cve_hint, demo=demo)

    return results


def run_target_scan(target: str, demo: bool, do_prevent: bool, export_fmt: str, dry_run: bool):
    if demo:
        report.console.print("[dim]Running in --demo mode (simulated data)[/dim]")
    elif Config.missing_keys():
        report.console.print(
            f"[yellow]Note: missing API keys for {', '.join(Config.missing_keys())} "
            f"— those sources will use simulated data automatically.[/yellow]"
        )

    results = gather(target, demo)
    verdict = correlate.score(results)

    blocked = False
    if do_prevent and verdict["severity"] >= Config.SEVERITY_PREVENT_THRESHOLD:
        outcome = firewall.block_ip(target, dry_run=dry_run)
        report.console.print(f"[bold]{outcome}[/bold]")
        blocked = "BLOCKED" in outcome

    report.print_report(target, results, verdict, blocked=blocked)
    state.update_from_scan(target, verdict)  # feed the live dashboard

    if export_fmt == "json":
        path = report.export_json(target, results, verdict)
        report.console.print(f"[green]Exported JSON report -> {path}[/green]")
    elif export_fmt == "html":
        path = report.export_html(target, results, verdict)
        report.console.print(f"[green]Exported HTML report -> {path}[/green]")


def run_live_monitor(iface):
    import detect

    def on_alert(alert):
        report.console.print(
            f"[bold red]LIVE ALERT[/bold red] {alert['type']} from {alert['src']} — {alert['detail']}"
        )
        state.update_from_live_alert(alert)  # feed the live dashboard

    report.console.print("[cyan]Starting live monitor (Ctrl+C to stop)...[/cyan]")
    monitor = detect.LiveMonitor(on_alert)
    try:
        monitor.start(iface=iface)
    except RuntimeError as e:
        report.console.print(f"[red]{e}[/red]")
        sys.exit(1)
    except KeyboardInterrupt:
        report.console.print("\n[cyan]Live monitor stopped.[/cyan]")


def main():
    parser = argparse.ArgumentParser(
        prog="VantaCore",
        description="Unified threat-intel aggregation & prevention CLI",
    )
    parser.add_argument("--target", help="IP address or domain to investigate")
    parser.add_argument("--prevent", action="store_true", help="Block target via iptables if severity is high")
    parser.add_argument("--dry-run", action="store_true", help="Print the block command instead of executing it")
    parser.add_argument("--export", choices=["json", "html"], help="Export the report to a file")
    parser.add_argument("--demo", action="store_true", help="Force simulated data (no API keys / no internet needed)")
    parser.add_argument("--live", action="store_true", help="Start live port-scan / DoS packet monitor (needs sudo)")
    parser.add_argument("--iface", default=None, help="Network interface for --live mode (default: scapy auto)")

    args = parser.parse_args()

    if args.live:
        run_live_monitor(args.iface)
        return

    if not args.target:
        parser.error("--target is required unless using --live")

    run_target_scan(
        target=args.target,
        demo=args.demo,
        do_prevent=args.prevent,
        export_fmt=args.export,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
