"""
report.py — renders the threat report to the terminal (Rich) and
can export the same data to JSON or a simple HTML file for
analyst documentation.
"""

import json
import os
from datetime import datetime

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box

from config import Config

console = Console()

VERDICT_COLOR = {
    "CRITICAL": "bold white on red",
    "HIGH": "bold red",
    "MEDIUM": "bold yellow",
    "LOW": "bold green",
}


def print_report(target: str, results: dict, verdict: dict, blocked: bool = False):
    console.rule(f"[bold cyan]VantaCore Threat Report — {target}")

    table = Table(box=box.ROUNDED, show_lines=False)
    table.add_column("Source", style="cyan", no_wrap=True)
    table.add_column("Finding", style="white")

    ab = results.get("abuseipdb", {})
    if ab.get("ok"):
        table.add_row("AbuseIPDB", f"{ab.get('abuse_score')}% malicious "
                                    f"({ab.get('total_reports')} reports) {ab.get('raw_note','')}")

    vt = results.get("virustotal", {})
    if vt.get("ok"):
        table.add_row("VirusTotal", f"{vt.get('malicious_engines')}/{vt.get('total_engines')} "
                                     f"engines flagged {vt.get('raw_note','')}")

    sh = results.get("shodan", {})
    if sh.get("ok"):
        table.add_row("Shodan", f"Open ports: {sh.get('open_ports')} | Vulns: {sh.get('vulns') or 'none'}")

    nvd = results.get("nvd", {})
    if nvd.get("ok"):
        table.add_row("NVD", f"{nvd.get('cve_id','N/A')} — CVSS {nvd.get('cvss_score')}")

    ipi = results.get("ipinfo", {})
    if ipi.get("ok"):
        table.add_row("IPinfo", f"{ipi.get('city')}, {ipi.get('country')} — {ipi.get('org')}")

    otx = results.get("otx", {})
    if otx.get("ok"):
        table.add_row("AlienVault OTX", f"{otx.get('pulse_count')} pulses, tags: {otx.get('tags')}")

    console.print(table)

    color = VERDICT_COLOR.get(verdict["verdict"], "white")
    body = (
        f"Threats matched : {', '.join(verdict['threats'])}\n"
        f"Severity        : {verdict['severity']}/10\n"
        f"Verdict         : [{color}]{verdict['verdict']}[/{color}]"
    )
    if blocked:
        body += "\n[bold red]ACTION: IP has been BLOCKED via iptables[/bold red]"

    console.print(Panel(body, title="Correlation Result", border_style=color.split()[-1]))


def export_json(target: str, results: dict, verdict: dict) -> str:
    os.makedirs(Config.REPORTS_DIR, exist_ok=True)
    path = os.path.join(Config.REPORTS_DIR, f"{target.replace('.', '_')}.json")
    payload = {
        "target": target,
        "timestamp": datetime.now().isoformat(),
        "results": results,
        "verdict": verdict,
    }
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)
    return path


def export_html(target: str, results: dict, verdict: dict) -> str:
    os.makedirs(Config.REPORTS_DIR, exist_ok=True)
    path = os.path.join(Config.REPORTS_DIR, f"{target.replace('.', '_')}.html")

    rows = ""
    for src, data in results.items():
        if data.get("ok"):
            rows += f"<tr><td>{src}</td><td>{ {k: v for k, v in data.items() if k not in ('source','ok')} }</td></tr>"

    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>VantaCore Report — {target}</title>
<style>
body {{ font-family: monospace; background:#0d1117; color:#c9d1d9; padding:2rem; }}
table {{ border-collapse: collapse; width:100%; margin-top:1rem; }}
td, th {{ border:1px solid #30363d; padding:8px; text-align:left; }}
h1 {{ color:#58a6ff; }}
.verdict {{ font-size:1.4rem; font-weight:bold; padding:0.5rem; }}
.CRITICAL {{ color:#ff4d4d; }} .HIGH {{ color:#ff8c42; }}
.MEDIUM {{ color:#ffd166; }} .LOW {{ color:#4caf50; }}
</style></head><body>
<h1>VantaCore Threat Report</h1>
<p>Target: <b>{target}</b><br>Generated: {datetime.now().isoformat()}</p>
<table><tr><th>Source</th><th>Finding</th></tr>{rows}</table>
<p class="verdict {verdict['verdict']}">Severity: {verdict['severity']}/10 — {verdict['verdict']}</p>
<p>Threats matched: {', '.join(verdict['threats'])}</p>
</body></html>"""

    with open(path, "w") as f:
        f.write(html)
    return path
