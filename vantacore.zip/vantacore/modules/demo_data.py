"""
demo_data.py
Generates realistic, DETERMINISTIC simulated results for every module.
Deterministic = same target always produces the same "fake" numbers,
so your demo looks consistent every time you re-run it, instead of
random garbage each run.

This is what keeps VantaCore presentable even with:
  - no internet in the demo room
  - an expired/rate-limited free-tier API key
  - a target IP that genuinely has no data yet
"""

import hashlib


def _seed(target: str) -> int:
    return int(hashlib.md5(target.encode()).hexdigest(), 16)


def fake_abuseipdb(ip: str) -> dict:
    s = _seed(ip)
    score = 60 + (s % 40)  # 60-99, looks like a "flagged" IP for demo purposes
    return {
        "source": "AbuseIPDB",
        "ok": True,
        "abuse_score": score,
        "total_reports": 5 + (s % 50),
        "country": "RU" if s % 3 == 0 else ("CN" if s % 3 == 1 else "US"),
        "tags": ["scanner", "brute-force"],
        "raw_note": "[DEMO DATA]",
    }


def fake_virustotal(ip: str) -> dict:
    s = _seed(ip)
    malicious = 10 + (s % 40)
    return {
        "source": "VirusTotal",
        "ok": True,
        "malicious_engines": malicious,
        "total_engines": 90,
        "categories": ["phishing"] if s % 2 == 0 else ["malware"],
        "raw_note": "[DEMO DATA]",
    }


def fake_shodan(ip: str) -> dict:
    s = _seed(ip)
    ports = [22, 80, 443, 3389, 8080]
    open_ports = ports[: 2 + (s % 3)]
    return {
        "source": "Shodan",
        "ok": True,
        "open_ports": open_ports,
        "vulns": ["CVE-2021-41773"] if 3389 in open_ports else [],
        "org": "DemoNet Hosting",
        "raw_note": "[DEMO DATA]",
    }


def fake_nvd(cve_hint: str = "") -> dict:
    s = _seed(cve_hint or "generic")
    cvss = round(6.0 + (s % 40) / 10, 1)
    return {
        "source": "NVD",
        "ok": True,
        "cve_id": "CVE-2021-41773",
        "cvss_score": min(cvss, 9.8),
        "description": "Path traversal vulnerability (demo lookup)",
        "raw_note": "[DEMO DATA]",
    }


def fake_ipinfo(ip: str) -> dict:
    s = _seed(ip)
    return {
        "source": "IPinfo",
        "ok": True,
        "city": "Unknown",
        "region": "Unknown",
        "country": "RU" if s % 3 == 0 else "US",
        "org": "AS0000 DemoNet",
        "raw_note": "[DEMO DATA]",
    }


def fake_otx(ip: str) -> dict:
    s = _seed(ip)
    return {
        "source": "AlienVault OTX",
        "ok": True,
        "pulse_count": 2 + (s % 8),
        "tags": ["scanning", "c2"] if s % 2 == 0 else ["phishing"],
        "raw_note": "[DEMO DATA]",
    }
