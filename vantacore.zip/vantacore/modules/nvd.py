"""
NVD module — CVE / CVSS severity lookup, used to score CVE exploit attempts.
Real endpoint: https://services.nvd.nist.gov/rest/json/cves/2.0
NVD does not require a key for light usage (just rate-limited).
"""

import requests
from config import Config
from modules.demo_data import fake_nvd


def query(cve_id: str = "", demo: bool = False) -> dict:
    if demo or not cve_id:
        return fake_nvd(cve_id)

    try:
        headers = {"apiKey": Config.NVD_KEY} if Config.NVD_KEY else {}
        resp = requests.get(
            "https://services.nvd.nist.gov/rest/json/cves/2.0",
            params={"cveId": cve_id},
            headers=headers,
            timeout=8,
        )
        resp.raise_for_status()
        vuln = resp.json()["vulnerabilities"][0]["cve"]
        metrics = vuln.get("metrics", {})
        cvss = 0.0
        for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
            if key in metrics:
                cvss = metrics[key][0]["cvssData"]["baseScore"]
                break
        return {
            "source": "NVD",
            "ok": True,
            "cve_id": cve_id,
            "cvss_score": cvss,
            "description": vuln["descriptions"][0]["value"][:120],
            "raw_note": f"CVSS {cvss}",
        }
    except Exception as e:
        fallback = fake_nvd(cve_id)
        fallback["raw_note"] = f"(live API failed, showing demo data — {e})"
        return fallback
