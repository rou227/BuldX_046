"""
IPinfo module — geolocation / ASN context for an IP.
Real endpoint: https://ipinfo.io/{ip}/json
"""

import requests
from config import Config
from modules.demo_data import fake_ipinfo


def query(ip: str, demo: bool = False) -> dict:
    if demo:
        return fake_ipinfo(ip)

    try:
        params = {"token": Config.IPINFO_KEY} if Config.IPINFO_KEY else {}
        resp = requests.get(f"https://ipinfo.io/{ip}/json", params=params, timeout=8)
        resp.raise_for_status()
        data = resp.json()
        return {
            "source": "IPinfo",
            "ok": True,
            "city": data.get("city", "Unknown"),
            "region": data.get("region", "Unknown"),
            "country": data.get("country", "Unknown"),
            "org": data.get("org", "Unknown"),
            "raw_note": f"{data.get('city', '?')}, {data.get('country', '?')}",
        }
    except Exception as e:
        fallback = fake_ipinfo(ip)
        fallback["raw_note"] = f"(live API failed, showing demo data — {e})"
        return fallback
