"""
VirusTotal module — multi-engine malicious verdict lookup for an IP/domain.
Real endpoint: https://www.virustotal.com/api/v3/ip_addresses/{ip}
"""

import requests
from config import Config
from modules.demo_data import fake_virustotal


def query(target: str, demo: bool = False) -> dict:
    if demo or not Config.VIRUSTOTAL_KEY:
        return fake_virustotal(target)

    try:
        resp = requests.get(
            f"https://www.virustotal.com/api/v3/ip_addresses/{target}",
            headers={"x-apikey": Config.VIRUSTOTAL_KEY},
            timeout=8,
        )
        resp.raise_for_status()
        stats = resp.json()["data"]["attributes"]["last_analysis_stats"]
        malicious = stats.get("malicious", 0)
        total = sum(stats.values())
        return {
            "source": "VirusTotal",
            "ok": True,
            "malicious_engines": malicious,
            "total_engines": total,
            "categories": [],
            "raw_note": f"{malicious}/{total} engines flagged",
        }
    except Exception as e:
        fallback = fake_virustotal(target)
        fallback["raw_note"] = f"(live API failed, showing demo data — {e})"
        return fallback
