"""
AlienVault OTX module — community threat pulses referencing this indicator.
Real endpoint: https://otx.alienvault.com/api/v1/indicators/IPv4/{ip}/general
"""

import requests
from config import Config
from modules.demo_data import fake_otx


def query(ip: str, demo: bool = False) -> dict:
    if demo or not Config.OTX_KEY:
        return fake_otx(ip)

    try:
        resp = requests.get(
            f"https://otx.alienvault.com/api/v1/indicators/IPv4/{ip}/general",
            headers={"X-OTX-API-KEY": Config.OTX_KEY},
            timeout=8,
        )
        resp.raise_for_status()
        data = resp.json()
        pulses = data.get("pulse_info", {}).get("pulses", [])
        tags = list({t for p in pulses for t in p.get("tags", [])})[:5]
        return {
            "source": "AlienVault OTX",
            "ok": True,
            "pulse_count": len(pulses),
            "tags": tags,
            "raw_note": f"{len(pulses)} community pulses",
        }
    except Exception as e:
        fallback = fake_otx(ip)
        fallback["raw_note"] = f"(live API failed, showing demo data — {e})"
        return fallback
