"""
AbuseIPDB module — IP reputation / abuse confidence score.
Real endpoint: https://api.abuseipdb.com/api/v2/check
"""

import requests
from config import Config
from modules.demo_data import fake_abuseipdb


def query(ip: str, demo: bool = False) -> dict:
    """
    Returns a normalized dict:
    {
        "source": "AbuseIPDB",
        "ok": bool,
        "abuse_score": int (0-100),
        "total_reports": int,
        "country": str,
        "tags": [str, ...],
        "raw_note": str
    }
    """
    if demo or not Config.ABUSEIPDB_KEY:
        return fake_abuseipdb(ip)

    try:
        resp = requests.get(
            "https://api.abuseipdb.com/api/v2/check",
            headers={"Key": Config.ABUSEIPDB_KEY, "Accept": "application/json"},
            params={"ipAddress": ip, "maxAgeInDays": 90, "verbose": True},
            timeout=8,
        )
        resp.raise_for_status()
        data = resp.json()["data"]
        categories = []
        for report in data.get("reports", [])[:5]:
            categories.extend(report.get("categories", []))

        return {
            "source": "AbuseIPDB",
            "ok": True,
            "abuse_score": data.get("abuseConfidenceScore", 0),
            "total_reports": data.get("totalReports", 0),
            "country": data.get("countryCode", "N/A"),
            "tags": ["scanner", "brute-force"] if categories else [],
            "raw_note": f"{data.get('totalReports', 0)} reports in last 90 days",
        }
    except Exception as e:
        # Network / key failure during a live demo -> degrade gracefully
        fallback = fake_abuseipdb(ip)
        fallback["raw_note"] = f"(live API failed, showing cached/demo data — {e})"
        return fallback
