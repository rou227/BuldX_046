"""
Shodan module — open ports, banners, known vulns for a host.
Real endpoint: https://api.shodan.io/shodan/host/{ip}
"""

import requests
from config import Config
from modules.demo_data import fake_shodan


def query(ip: str, demo: bool = False) -> dict:
    if demo or not Config.SHODAN_KEY:
        return fake_shodan(ip)

    try:
        resp = requests.get(
            f"https://api.shodan.io/shodan/host/{ip}",
            params={"key": Config.SHODAN_KEY},
            timeout=8,
        )
        resp.raise_for_status()
        data = resp.json()
        return {
            "source": "Shodan",
            "ok": True,
            "open_ports": data.get("ports", []),
            "vulns": list(data.get("vulns", [])),
            "org": data.get("org", "Unknown"),
            "raw_note": f"{len(data.get('ports', []))} open ports found",
        }
    except Exception as e:
        fallback = fake_shodan(ip)
        fallback["raw_note"] = f"(live API failed, showing demo data — {e})"
        return fallback
