"""
correlate.py — VantaCore's rule-based correlation engine.

Takes the raw normalized results from every feed module and produces:
  1. A single unified severity score, 0-10
  2. A verdict label: LOW / MEDIUM / HIGH / CRITICAL
  3. Which of the 6 threat categories this indicator matches
"""

THREAT_CATEGORIES = [
    "Brute Force / Credential Stuffing",
    "Port Scanning",
    "Known Malicious IP",
    "Phishing Domain",
    "CVE Exploit Attempt",
    "DoS / Flood",
]


def score(results: dict) -> dict:
    weights = {}
    threats = set()

    ab = results.get("abuseipdb", {})
    if ab.get("ok"):
        w = round((ab.get("abuse_score", 0) / 100) * 4.0, 2)
        weights["AbuseIPDB"] = w
        if ab.get("abuse_score", 0) >= 50:
            threats.add("Known Malicious IP")
        if "brute-force" in ab.get("tags", []):
            threats.add("Brute Force / Credential Stuffing")

    vt = results.get("virustotal", {})
    if vt.get("ok") and vt.get("total_engines"):
        ratio = vt.get("malicious_engines", 0) / vt.get("total_engines", 1)
        w = round(ratio * 3.0, 2)
        weights["VirusTotal"] = w
        if ratio >= 0.15:
            threats.add("Known Malicious IP")
        if "phishing" in vt.get("categories", []):
            threats.add("Phishing Domain")

    sh = results.get("shodan", {})
    if sh.get("ok"):
        open_ports = sh.get("open_ports", [])
        w = min(len(open_ports) * 0.3, 1.5)
        weights["Shodan"] = round(w, 2)
        if len(open_ports) >= 3:
            threats.add("Port Scanning")
        if sh.get("vulns"):
            threats.add("CVE Exploit Attempt")

    nvd = results.get("nvd", {})
    if nvd.get("ok") and nvd.get("cvss_score"):
        w = round((nvd.get("cvss_score", 0) / 10) * 1.0, 2)
        weights["NVD"] = w
        if nvd.get("cvss_score", 0) >= 7.0:
            threats.add("CVE Exploit Attempt")

    otx = results.get("otx", {})
    if otx.get("ok"):
        w = min(otx.get("pulse_count", 0) * 0.05, 0.5)
        weights["OTX"] = round(w, 2)
        if "c2" in otx.get("tags", []) or "scanning" in otx.get("tags", []):
            threats.add("Port Scanning")
        if "phishing" in otx.get("tags", []):
            threats.add("Phishing Domain")

    total = round(min(sum(weights.values()), 10.0), 1)

    if total >= 8.0:
        verdict = "CRITICAL"
    elif total >= 6.0:
        verdict = "HIGH"
    elif total >= 3.0:
        verdict = "MEDIUM"
    else:
        verdict = "LOW"

    return {
        "severity": total,
        "verdict": verdict,
        "threats": sorted(threats) or ["None detected"],
        "weights": weights,
    }
