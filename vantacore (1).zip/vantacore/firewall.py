"""
firewall.py — the "PREVENT" step. Blocks/unblocks an IP using iptables.

Safety notes for the demo:
  - Requires sudo / root (Kali's default user has sudo).
  - dry_run=True just prints the command instead of executing it.
"""

import platform
import subprocess


def block_ip(ip: str, dry_run: bool = False) -> str:
    cmd = ["sudo", "iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"]

    if dry_run or platform.system() != "Linux":
        return f"[DRY RUN] Would execute: {' '.join(cmd)}"

    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=5)
        return f"BLOCKED: {ip} dropped via iptables"
    except subprocess.CalledProcessError as e:
        return f"FAILED to block {ip}: {e.stderr.strip()}"
    except FileNotFoundError:
        return "FAILED: iptables not found on this system"
    except Exception as e:
        return f"FAILED to block {ip}: {e}"


def unblock_ip(ip: str, dry_run: bool = False) -> str:
    cmd = ["sudo", "iptables", "-D", "INPUT", "-s", ip, "-j", "DROP"]

    if dry_run or platform.system() != "Linux":
        return f"[DRY RUN] Would execute: {' '.join(cmd)}"

    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=5)
        return f"UNBLOCKED: {ip} rule removed from iptables"
    except subprocess.CalledProcessError as e:
        return f"FAILED to unblock {ip}: {e.stderr.strip()} (was it actually blocked?)"
    except Exception as e:
        return f"FAILED to unblock {ip}: {e}"


def list_blocked() -> str:
    """Show current DROP rules in iptables (best-effort demo helper)."""
    try:
        result = subprocess.run(
            ["sudo", "iptables", "-L", "INPUT", "-n"],
            check=True, capture_output=True, text=True, timeout=5,
        )
        return result.stdout
    except Exception as e:
        return f"Could not list rules: {e}"
