#!/usr/bin/env python3
"""
VantaCore — unified CLI threat-intelligence, correlation & prevention tool.

CORE USAGE
  python3 vantacore.py --target 45.33.32.156
  python3 vantacore.py --target 45.33.32.156 --demo
  python3 vantacore.py --target 45.33.32.156 --prevent
  python3 vantacore.py --target 45.33.32.156 --export json|html
  python3 vantacore.py --live

BLOCKLIST / WHITELIST MANAGEMENT
  python3 vantacore.py --list-blocked
  python3 vantacore.py --list-whitelist
  python3 vantacore.py --unblock 45.33.32.156
  python3 vantacore.py --whitelist-add 8.8.8.8 --note "trusted DNS"
  python3 vantacore.py --whitelist-remove 8.8.8.8
"""

import argparse
import sys

from config import Config
import correlate
import report
import firewall
import state
import blocklist
from scanner import gather


def run_target_scan(target: str, demo: bool, do_prevent: bool, export_fmt: str, dry_run: bool):
    if demo:
        report.console.print("[dim]Running in --demo mode (simulated data)[/dim]")
    elif Config.missing_keys():
        report.console.print(
            f"[yellow]Note: missing API keys for {', '.join(Config.missing_keys())} "
            f"— those sources will use simulated data automatically.[/yellow]"
        )

    results = gather(target, demo)
    verdict = correlate.score(results)

    blocked = False
    whitelisted = blocklist.is_whitelisted(target)

    if do_prevent:
        if whitelisted:
            report.console.print(
                f"[bold green]{target} is WHITELISTED — skipping prevention even though "
                f"severity is {verdict['severity']}/10.[/bold green]"
            )
        elif verdict["severity"] >= Config.SEVERITY_PREVENT_THRESHOLD:
            outcome = firewall.block_ip(target, dry_run=dry_run)
            report.console.print(f"[bold]{outcome}[/bold]")
            blocked = "BLOCKED" in outcome
            if blocked and not dry_run:
                blocklist.add_to_blocklist(
                    target,
                    severity=verdict["severity"],
                    threats=verdict["threats"],
                    note="auto-blocked by --prevent",
                )

    report.print_report(target, results, verdict, blocked=blocked, whitelisted=whitelisted)
    state.update_from_scan(target, results, verdict)

    if export_fmt == "json":
        path = report.export_json(target, results, verdict)
        report.console.print(f"[green]Exported JSON report -> {path}[/green]")
    elif export_fmt == "html":
        path = report.export_html(target, results, verdict)
        report.console.print(f"[green]Exported HTML report -> {path}[/green]")


def run_live_monitor(iface):
    import detect

    def on_alert(alert):
        report.console.print(
            f"[bold red]LIVE ALERT[/bold red] {alert['type']} from {alert['src']} — {alert['detail']}"
        )
        state.update_from_live_alert(alert)

    report.console.print("[cyan]Starting live monitor (Ctrl+C to stop)...[/cyan]")
    monitor = detect.LiveMonitor(on_alert)
    try:
        monitor.start(iface=iface)
    except RuntimeError as e:
        report.console.print(f"[red]{e}[/red]")
        sys.exit(1)
    except KeyboardInterrupt:
        report.console.print("\n[cyan]Live monitor stopped.[/cyan]")


def handle_management_commands(args) -> bool:
    """
    Handles all blocklist/whitelist commands. Returns True if one was
    handled (so main() can exit early without requiring --target).
    """
    if args.list_blocked:
        report.print_blocklist(blocklist.list_blocklist())
        return True

    if args.list_whitelist:
        report.print_whitelist(blocklist.list_whitelist())
        return True

    if args.unblock:
        ip = args.unblock
        outcome = firewall.unblock_ip(ip, dry_run=args.dry_run)
        report.console.print(f"[bold]{outcome}[/bold]")
        if not args.dry_run and blocklist.remove_from_blocklist(ip):
            report.console.print(f"[green]Removed {ip} from persistent blocklist.[/green]")
        return True

    if args.whitelist_add:
        ip = args.whitelist_add
        blocklist.add_to_whitelist(ip, note=args.note or "")
        report.console.print(f"[green]{ip} added to whitelist — it will never be auto-blocked.[/green]")
        return True

    if args.whitelist_remove:
        ip = args.whitelist_remove
        if blocklist.remove_from_whitelist(ip):
            report.console.print(f"[yellow]{ip} removed from whitelist.[/yellow]")
        else:
            report.console.print(f"[dim]{ip} was not in the whitelist.[/dim]")
        return True

    if args.restore_blocks:
        data = blocklist.list_blocklist()
        if not data:
            report.console.print("[dim]Blocklist is empty — nothing to restore.[/dim]")
        for ip in data:
            outcome = firewall.block_ip(ip, dry_run=args.dry_run)
            report.console.print(f"[bold]{outcome}[/bold]")
        return True

    return False


def main():
    parser = argparse.ArgumentParser(
        prog="VantaCore",
        description="Unified threat-intel aggregation, correlation & prevention CLI",
    )
    parser.add_argument("--target", help="IP address or domain to investigate")
    parser.add_argument("--prevent", action="store_true", help="Block target via iptables if severity is high")
    parser.add_argument("--dry-run", action="store_true", help="Print firewall commands instead of executing them")
    parser.add_argument("--export", choices=["json", "html"], help="Export the report to a file")
    parser.add_argument("--demo", action="store_true", help="Force simulated data (no API keys / no internet needed)")
    parser.add_argument("--live", action="store_true", help="Start live port-scan / DoS packet monitor (needs sudo)")
    parser.add_argument("--iface", default=None, help="Network interface for --live mode (default: scapy auto)")

    # --- blocklist / whitelist management ---
    parser.add_argument("--list-blocked", action="store_true", help="Show all IPs in the persistent blocklist")
    parser.add_argument("--list-whitelist", action="store_true", help="Show all IPs in the whitelist")
    parser.add_argument("--unblock", metavar="IP", help="Remove the iptables rule and blocklist entry for an IP")
    parser.add_argument("--whitelist-add", metavar="IP", help="Add an IP to the whitelist (never auto-blocked)")
    parser.add_argument("--whitelist-remove", metavar="IP", help="Remove an IP from the whitelist")
    parser.add_argument("--restore-blocks", action="store_true",
                         help="Re-apply iptables rules for every IP in the blocklist (use after a reboot)")
    parser.add_argument("--note", help="Optional note to attach to --whitelist-add")

    args = parser.parse_args()

    if handle_management_commands(args):
        return

    if args.live:
        run_live_monitor(args.iface)
        return

    if not args.target:
        parser.error("--target is required unless using --live or a management flag "
                      "(--list-blocked, --list-whitelist, --unblock, --whitelist-add, "
                      "--whitelist-remove, --restore-blocks)")

    run_target_scan(
        target=args.target,
        demo=args.demo,
        do_prevent=args.prevent,
        export_fmt=args.export,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
