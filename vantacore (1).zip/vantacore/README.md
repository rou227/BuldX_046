# VantaCore

A single-CLI threat-intelligence aggregator + correlation engine + prevention
tool, built for Kali Linux. It pulls data from AbuseIPDB, VirusTotal, Shodan,
AlienVault OTX and NVD/NIST, scores a target 0–10 with a rule-based
correlation engine, and can automatically block high-severity IPs with
iptables. It also ships a live browser dashboard, and a persistent
blocklist/whitelist system.

Covers 6 threat categories:
1. Brute Force / Credential Stuffing
2. Port Scanning
3. Known Malicious IPs
4. Phishing Domains
5. CVE Exploit Attempts
6. DoS / Flood

---

## 1. Setup on your Kali VM

```bash
cd vantacore
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

cp .env.example .env    # optional -- paste API keys if you have them
```

## 2. Core commands

```bash
python3 vantacore.py --target 45.33.32.156 --demo
python3 vantacore.py --target 45.33.32.156 --demo --prevent
python3 vantacore.py --target 45.33.32.156 --demo --prevent --dry-run
python3 vantacore.py --target 45.33.32.156 --demo --export json
sudo python3 vantacore.py --live
```

## 3. NEW: Blocklist & whitelist management

iptables rules don't survive a reboot, and until now VantaCore had no memory
of what it had blocked once a terminal closed. Now every real block is
recorded permanently in `blocklist.json`, and you can mark trusted IPs so
they're never auto-blocked even if a feed flags them.

```bash
# See every IP VantaCore has ever blocked, with severity + reason
python3 vantacore.py --list-blocked

# Whitelist a trusted IP -- it will be skipped even with --prevent
python3 vantacore.py --whitelist-add 8.8.8.8 --note "trusted DNS"

# See the whitelist
python3 vantacore.py --list-whitelist

# Remove an IP from the whitelist
python3 vantacore.py --whitelist-remove 8.8.8.8

# Unblock an IP: removes the iptables rule AND the blocklist record
python3 vantacore.py --unblock 45.33.32.156

# After a reboot, iptables rules are gone but blocklist.json isn't --
# this re-applies every rule in your persistent blocklist
python3 vantacore.py --restore-blocks
```

If you run a scan with `--prevent` against a whitelisted IP, VantaCore
prints a clear message and skips the firewall action entirely, no matter
how high the severity score is:
```
8.8.8.8 is WHITELISTED — skipping prevention even though severity is 8.5/10.
```

The dashboard also shows a live "Persistent Blocklist" panel underneath the
radar, pulling straight from `blocklist.json` via a new `/api/blocklist`
endpoint -- so you can demo a block happening and watch it appear in that
table in real time.

## 4. Live dashboard (full self-service UI)

The dashboard is now a complete control panel, not just a status light --
you can run scans and block IPs directly from the browser, with zero CLI
needed. Every button on the page calls into the exact same real backend
(`scanner.gather()`, `correlate.score()`, `firewall.py`, `blocklist.py`)
that the CLI uses, so results are identical either way.

```bash
python3 dashboard/server.py
# open http://127.0.0.1:5050
```

What you can do from the page:
- Type a target IP into the field and click **TRIGGER RECON SCAN** -- runs
  a real scan against AbuseIPDB, VirusTotal, Shodan, IPinfo, OTX and NVD,
  the same as `vantacore.py --target <ip>` on the CLI.
- Watch the **severity gauge** (0-10), the **SECURE / UNDER ATTACK** badge,
  the **6 intelligence category bars** (Port Scanning, Malware & Engines,
  Reputation & Abuse, Threat Feeds, Geolocation, Vulnerabilities), and the
  **live event feed** all update from that real scan.
- Open the **recon panel** to see the full per-source breakdown (open
  ports, CVEs, abuse score, etc.) as individual module cards.
- Use the **firewall panel** to submit an IP + reason + dry-run toggle --
  a real block runs `iptables` and is written to `blocklist.json`
  permanently; a dry-run block only shows in the table for this session
  and touches nothing.

You can still also run scans from a second terminal with
`python3 vantacore.py --target 45.33.32.156 --demo` (or `sudo python3
vantacore.py --live` for the packet monitor) -- either path updates the
same dashboard, since both go through the same `scanner.py` / `state.py`.

## 5. How it works — by point (for your presentation)

**Step 1 — Input**
You give VantaCore a single IP or domain via `--target`.

**Step 2 — Parallel API calls**
VantaCore queries AbuseIPDB, VirusTotal, Shodan, IPinfo and AlienVault OTX
at the same time using a thread pool. NVD is queried afterward using any
CVE that Shodan reported.

**Step 3 — Correlation engine (`correlate.py`)**
Each source contributes a weighted score (AbuseIPDB confidence, VirusTotal
detection ratio, open ports, CVSS, OTX pulses) that sums into a unified
severity score out of 10, and is pattern-matched against the 6 threat
categories.

**Step 4 — Prevent, with memory**
If `--prevent` is passed and severity crosses the threshold (7.0 by
default), VantaCore checks the whitelist first. If the target isn't
whitelisted, it blocks via iptables AND writes a permanent record to
`blocklist.json` -- so the block survives even after the terminal closes,
and `--restore-blocks` can bring every rule back after a reboot.

**Step 5 — Report**
Rich table + severity panel in the terminal, exportable to JSON or HTML.

**Bonus — Live monitor (`detect.py`)**
`--live` uses scapy to flag port scans and DoS floods on real traffic,
no API needed.

**Bonus — Live dashboard**
A real Flask app reading the same severity/threat/blocklist data the CLI
just calculated -- not an animation.

## 6. Project structure

```
vantacore/
├── vantacore.py         # CLI entry point — argument parsing, orchestration
├── scanner.py            # shared gather() — used by BOTH the CLI and the dashboard
├── config.py              # API key loading, thresholds
├── correlate.py            # the scoring / correlation engine
├── report.py                # Rich console output + JSON/HTML export
├── firewall.py                # iptables block/unblock (with dry-run safety)
├── blocklist.py                 # persistent blocklist/whitelist storage
├── detect.py                      # live scapy-based port-scan/DoS detection
├── state.py                         # in-memory state feeding the dashboard API
├── dashboard/
│   ├── server.py                      # Flask app: /api/status, /api/recon,
│   │                                   # /api/firewall, /api/scan/trigger
│   └── static/index.html                # full self-service control-panel UI
├── modules/
│   ├── abuseipdb.py
│   ├── virustotal.py
│   ├── shodan_api.py
│   ├── nvd.py
│   ├── ipinfo.py
│   ├── otx.py
│   └── demo_data.py    # deterministic simulated data for --demo mode
├── requirements.txt
└── .env.example
```

## 7. If something breaks right before your demo

- `ModuleNotFoundError` → `pip install -r requirements.txt` inside your venv.
- No internet in the room → add `--demo` to every command.
- `iptables: permission denied` → forgot `sudo` before `python3`.
- Dashboard says "Unable to connect" → you must run `python3 dashboard/server.py`
  in its OWN terminal tab and leave it alone. Run scans in a SEPARATE tab.
  Never type anything into the tab that's running the server.
- Want to prove prevention without risking anything → always use `--dry-run`
  in front of a live audience unless you've tested the exact command first.
