"""
state.py — persistent in-memory state for the VantaCore dashboard.

This matches the data contract the dashboard frontend (dashboard/static/index.html)
expects: get_status_summary(), get_recon(), get_firewall(), add_firewall_block(),
update_from_scan(). What's different from a mock version is that every field
here is populated from REAL data:

  - update_from_scan() is called with the REAL results from scanner.gather()
    and the REAL correlation verdict from correlate.score() -- by both the
    CLI (vantacore.py --target ...) and the dashboard's own
    "TRIGGER RECON SCAN" button, so the two stay consistent.
  - The firewall table is seeded from, and kept in sync with, the
    PERSISTENT blocklist.json (via blocklist.py) -- a real block survives
    a server restart. A "dry run" block is shown in the live table for
    the rest of this session but is never written to blocklist.json or
    iptables, matching the CLI's --dry-run behavior.
  - system.demo_mode / missing_keys are read live from config.Config, not
    hardcoded.
"""

import threading
import time

from config import Config
import blocklist
import firewall

_lock = threading.Lock()


def _seed_blocked_ips():
    """Load the persistent blocklist into the in-memory table at startup."""
    rows = []
    data = blocklist.list_blocklist()
    for i, (ip, meta) in enumerate(sorted(data.items(), key=lambda kv: kv[1].get("blocked_at", ""), reverse=True)):
        rows.append({
            "rule_id": f"RULE-{1001 + i}",
            "ip": ip,
            "reason": meta.get("note") or ", ".join(meta.get("threats", [])) or "Blocked by VantaCore",
            "action_time": meta.get("blocked_at", ""),
            "dry_run": False,  # anything actually in blocklist.json was a real block
        })
    return rows


DEFAULT_STATE = {
    "status": "SECURE",
    "severity": 0.0,
    "target": None,
    "active_threats": [],
    "events": [
        {
            "epoch": int(time.time()),
            "time": time.strftime("%H:%M:%S"),
            "message": "VantaCore engine initialized. Real-time telemetry online.",
            "level": "info",
            "threat_type": "SYSTEM",
        }
    ],
    "categories": [
        {"name": "Port Scanning", "threat_count": 0, "status": "NOMINAL"},
        {"name": "Malware & Engines", "threat_count": 0, "status": "NOMINAL"},
        {"name": "Reputation & Abuse", "threat_count": 0, "status": "NOMINAL"},
        {"name": "Threat Feeds (OTX)", "threat_count": 0, "status": "NOMINAL"},
        {"name": "Geolocation & Org", "threat_count": 0, "status": "NOMINAL"},
        {"name": "Vulnerabilities (NVD)", "threat_count": 0, "status": "NOMINAL"},
    ],
    "recon": None,
}

_state = dict(DEFAULT_STATE)
_state["blocked_ips"] = _seed_blocked_ips()


def get_status_summary():
    with _lock:
        return {
            "status": _state["status"],
            "severity": _state["severity"],
            "target": _state["target"],
            "active_threats": list(_state["active_threats"]),
            "events": list(_state["events"]),
            "categories": [dict(c) for c in _state["categories"]],
            "system": {
                "demo_mode": bool(Config.missing_keys()),
                "missing_keys": Config.missing_keys(),
            },
        }


def get_recon():
    with _lock:
        if _state["recon"] is None:
            return {"status": "no_scan_yet", "target": _state["target"], "recon": None}
        return {
            "status": "ok",
            "target": _state["target"],
            "recon": _state["recon"],
        }


def get_firewall():
    with _lock:
        return {"blocked_ips": list(_state["blocked_ips"])}


def add_firewall_block(ip: str, reason: str, dry_run: bool = True):
    """
    Called from the dashboard's "Block IP" form.
    Runs the REAL firewall action, and persists to blocklist.json only
    when it's not a dry run -- exactly like the CLI's --prevent/--dry-run.
    """
    outcome = firewall.block_ip(ip, dry_run=dry_run)

    if not dry_run and "BLOCKED" in outcome:
        blocklist.add_to_blocklist(ip, severity=None, threats=[], note=reason)

    with _lock:
        rule_id = f"RULE-{len(_state['blocked_ips']) + 1001}"
        action_time = time.strftime("%H:%M:%S")
        rule = {
            "rule_id": rule_id,
            "ip": ip,
            "reason": reason,
            "action_time": action_time,
            "dry_run": dry_run,
        }
        _state["blocked_ips"].insert(0, rule)
        event_msg = f"Firewall Rule {rule_id}: {outcome}. Reason: {reason}"
        _state["events"].insert(0, {
            "epoch": int(time.time()),
            "time": action_time,
            "message": event_msg,
            "level": "info" if dry_run else "alert",
            "threat_type": "FIREWALL",
        })
        return rule


def update_from_scan(target: str, results: dict, verdict: dict):
    """
    Called after a REAL scan (scanner.gather + correlate.score) from
    either the CLI or the dashboard's scan-trigger endpoint.

    results: raw per-source dicts (abuseipdb, virustotal, shodan, ipinfo, otx, nvd)
    verdict: the dict returned by correlate.score(results)
             -> {"severity": float, "verdict": str, "threats": [...], "weights": {...}}
    """
    with _lock:
        _state["target"] = target
        _state["recon"] = results
        _state["severity"] = verdict["severity"]
        _state["active_threats"] = [] if verdict["threats"] == ["None detected"] else verdict["threats"]
        _state["status"] = "UNDER_ATTACK" if verdict["verdict"] in ("HIGH", "CRITICAL") else "SECURE"

        shodan = results.get("shodan", {})
        open_ports = shodan.get("open_ports", [])
        port_threats = len(open_ports)

        vt = results.get("virustotal", {})
        vt_mal = vt.get("malicious_engines", 0)

        abuse = results.get("abuseipdb", {})
        abuse_score = abuse.get("abuse_score", 0)

        otx = results.get("otx", {})
        pulse_count = otx.get("pulse_count", 0)

        nvd = results.get("nvd", {})
        nvd_cve = nvd.get("cve_id", "")
        nvd_score = nvd.get("cvss_score", 0.0)

        _state["categories"] = [
            {
                "name": "Port Scanning",
                "threat_count": port_threats,
                "status": "ALERT" if port_threats > 3 else ("WARN" if port_threats > 0 else "NOMINAL"),
            },
            {
                "name": "Malware & Engines",
                "threat_count": vt_mal,
                "status": "ALERT" if vt_mal > 2 else ("WARN" if vt_mal > 0 else "NOMINAL"),
            },
            {
                "name": "Reputation & Abuse",
                "threat_count": abuse_score,
                "status": "ALERT" if abuse_score > 50 else ("WARN" if abuse_score > 10 else "NOMINAL"),
            },
            {
                "name": "Threat Feeds (OTX)",
                "threat_count": pulse_count,
                "status": "ALERT" if pulse_count > 3 else ("WARN" if pulse_count > 0 else "NOMINAL"),
            },
            {
                "name": "Geolocation & Org",
                "threat_count": 0,
                "status": "NOMINAL",
            },
            {
                "name": "Vulnerabilities (NVD)",
                "threat_count": 1 if nvd_cve else 0,
                "status": "ALERT" if nvd_score >= 7.0 else ("WARN" if nvd_cve else "NOMINAL"),
            },
        ]

        now_str = time.strftime("%H:%M:%S")
        _state["events"].insert(0, {
            "epoch": int(time.time()),
            "time": now_str,
            "message": (f"Scan completed for target {target}. "
                        f"Severity: {verdict['severity']}/10.0 — {verdict['verdict']}"),
            "level": "alert" if verdict["severity"] >= 5.0 else "info",
            "threat_type": "SCAN",
        })


def update_from_live_alert(alert: dict):
    """Called by the CLI's --live packet monitor (detect.py) on each real alert."""
    with _lock:
        _state["status"] = "UNDER_ATTACK"
        if alert["type"] not in _state["active_threats"]:
            _state["active_threats"].append(alert["type"])
        now_str = time.strftime("%H:%M:%S")
        _state["events"].insert(0, {
            "epoch": int(time.time()),
            "time": now_str,
            "message": f"LIVE: {alert['type']} from {alert['src']} — {alert['detail']}",
            "level": "alert",
            "threat_type": alert["type"],
        })
