"""
dashboard/server.py — Flask backend for the VantaCore cybersecurity dashboard.

Run this in ONE terminal:
    python3 dashboard/server.py
Then open http://127.0.0.1:5050 in a browser.

Every endpoint here runs VantaCore's REAL pipeline -- there is no mock
data. "TRIGGER RECON SCAN" in the browser runs the exact same
scanner.gather() + correlate.score() pipeline as `vantacore.py --target`
on the command line, and "Block IP" runs the exact same firewall.block_ip()
+ persistent blocklist.py used by `--prevent` / `--unblock` on the CLI.

Endpoints:
  GET  /api/status          fast poll (dashboard polls this every ~3s)
  GET  /api/recon           last real scan's full per-source results
  GET  /api/firewall        current blocklist (persistent + this-session dry-runs)
  POST /api/firewall/block  { ip, reason, dry_run } -> runs a real (or dry-run) block
  POST /api/scan/trigger    { target, demo } -> runs a real scan against `target`
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, jsonify, request, send_from_directory

import state
import correlate
from scanner import gather

app = Flask(__name__, static_folder="static")


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/static/<path:filename>")
def serve_static(filename):
    return send_from_directory(app.static_folder, filename)


@app.route("/api/status", methods=["GET"])
def get_status():
    return jsonify(state.get_status_summary())


@app.route("/api/recon", methods=["GET"])
def get_recon():
    return jsonify(state.get_recon())


@app.route("/api/firewall", methods=["GET"])
def get_firewall():
    return jsonify(state.get_firewall())


@app.route("/api/firewall/block", methods=["POST"])
def post_firewall_block():
    data = request.get_json(force=True, silent=True) or {}
    ip = data.get("ip")
    reason = data.get("reason", "Manual rule added via VantaCore UI")
    dry_run = data.get("dry_run", True)

    if not ip:
        return jsonify({"error": "IP address is required"}), 400

    rule = state.add_firewall_block(ip=ip, reason=reason, dry_run=dry_run)
    return jsonify({"success": True, "rule": rule, "blocked_ips": state.get_firewall()["blocked_ips"]})


@app.route("/api/scan/trigger", methods=["POST"])
def trigger_scan():
    data = request.get_json(force=True, silent=True) or {}
    target = data.get("target", "8.8.8.8")
    demo = bool(data.get("demo", False))  # per-scan override; each module also
                                           # auto-falls-back to demo data on its own
                                           # if that source's API key is missing

    results = gather(target, demo=demo)
    verdict = correlate.score(results)
    state.update_from_scan(target, results, verdict)

    return jsonify({
        "success": True,
        "target": target,
        "verdict": verdict,
        "status": state.get_status_summary(),
        "recon": state.get_recon(),
    })


if __name__ == "__main__":
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", 5050))
    print(f"[VantaCore] Server starting on http://{host}:{port} (Kali Linux ready)")
    app.run(host=host, port=port, debug=False)
