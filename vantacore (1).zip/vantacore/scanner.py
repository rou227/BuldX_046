"""
scanner.py — shared scan orchestration.

Both the CLI (vantacore.py --target ...) and the dashboard's browser
"TRIGGER RECON SCAN" button (dashboard/server.py) call gather() here, so
a scan started from a terminal and one started from the web UI both run
the exact same real pipeline against AbuseIPDB, VirusTotal, Shodan,
IPinfo, OTX and NVD.
"""

import concurrent.futures as cf

from modules import abuseipdb, virustotal, shodan_api, nvd, ipinfo, otx


def gather(target: str, demo: bool = False) -> dict:
    """Runs every feed lookup IN PARALLEL for speed."""
    jobs = {
        "abuseipdb": (abuseipdb.query, target),
        "virustotal": (virustotal.query, target),
        "shodan": (shodan_api.query, target),
        "ipinfo": (ipinfo.query, target),
        "otx": (otx.query, target),
    }
    results = {}
    with cf.ThreadPoolExecutor(max_workers=len(jobs)) as pool:
        futures = {pool.submit(fn, tgt, demo=demo): name for name, (fn, tgt) in jobs.items()}
        for fut in cf.as_completed(futures):
            name = futures[fut]
            try:
                results[name] = fut.result()
            except Exception as e:
                results[name] = {"source": name, "ok": False, "raw_note": str(e)}

    # NVD depends on a CVE hint, which we only know after Shodan reports vulns.
    shodan_vulns = results.get("shodan", {}).get("vulns", [])
    cve_hint = shodan_vulns[0] if shodan_vulns else ""
    results["nvd"] = nvd.query(cve_hint, demo=demo)

    return results
