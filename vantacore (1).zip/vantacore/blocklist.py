"""
blocklist.py — persistent blocklist / whitelist management.

WHY THIS EXISTS:
iptables rules do NOT survive a reboot, and until now VantaCore had no
memory of what it had blocked once a terminal closed. This module keeps
a permanent JSON record of every IP VantaCore has blocked (with why and
when), plus a whitelist of trusted IPs that should NEVER be
auto-blocked even if a feed flags them as malicious.

Two flat JSON files live next to this script:
  blocklist.json  -> { "1.2.3.4": {blocked_at, severity, threats, note} }
  whitelist.json  -> { "1.2.3.4": {added_at, note} }
"""

import json
import os
import time

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
BLOCKLIST_FILE = os.path.join(DATA_DIR, "blocklist.json")
WHITELIST_FILE = os.path.join(DATA_DIR, "whitelist.json")


def _load(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return {}


def _save(path: str, data: dict):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


# ---------------------------------------------------------------- blocklist

def add_to_blocklist(ip: str, severity: float = None, threats=None, note: str = ""):
    data = _load(BLOCKLIST_FILE)
    data[ip] = {
        "blocked_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "severity": severity,
        "threats": threats or [],
        "note": note,
    }
    _save(BLOCKLIST_FILE, data)


def remove_from_blocklist(ip: str) -> bool:
    data = _load(BLOCKLIST_FILE)
    if ip in data:
        del data[ip]
        _save(BLOCKLIST_FILE, data)
        return True
    return False


def is_blocked(ip: str) -> bool:
    return ip in _load(BLOCKLIST_FILE)


def list_blocklist() -> dict:
    return _load(BLOCKLIST_FILE)


# ---------------------------------------------------------------- whitelist

def add_to_whitelist(ip: str, note: str = ""):
    data = _load(WHITELIST_FILE)
    data[ip] = {
        "added_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "note": note,
    }
    _save(WHITELIST_FILE, data)


def remove_from_whitelist(ip: str) -> bool:
    data = _load(WHITELIST_FILE)
    if ip in data:
        del data[ip]
        _save(WHITELIST_FILE, data)
        return True
    return False


def is_whitelisted(ip: str) -> bool:
    return ip in _load(WHITELIST_FILE)


def list_whitelist() -> dict:
    return _load(WHITELIST_FILE)
